import json

## B: Create a function that loops through the .json class list and prints out each value.
def display_students(student_list):
    for student in student_list:
       print(f"{student['L_Name']}, {student['F_Name']} : "
             f"ID = {student['Student_ID']}, Email = {student['Email']}")

def main():
    file_name = "student.json"
    ## C: Output notification to the user that this is the origianl student list.
    try:
       with open(file_name, "r") as file:
           student_list = json.load(file)
    except FileNotFoundError:
       print(f"Error: The file '{file_name}' was not found.")
       return

## D: Call my print function
    print("--- Notification: This is the original student list ---")
    display_students(student_list)
    print("-" * 50)

## E: Add my last name, first name, fictional ID, and email to the class using append()
    new_student = {
          "F_Name": "Cece",
          "L_Name": "Geisler",
          "Student_ID": 10240,
          "Email": "cgeisler@email.com"

    }
    student_list.append(new_student)

## F & G: Output notification to the user that this is the updated student list and call print for updated list.
    print("--- Notification: This is the updated student list ---")
    display_students(student_list)
    print("-" * 50)

## H: Use the JSON dump() funciton to append the new data to the .json file.
    with open(file_name, "w") as file:
       json.dump(student_list, file, indent=4)

## I: Output notification to the user that the .json file was updated.
    print(f"SUCCESS: The {file_name} file has been updated with the new student data.")

if __name__ == "__main__":
   main()